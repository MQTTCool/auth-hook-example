This folder contains the binaries needed to install the MQTT Extender Authentication and Authorization Demo Hook into Lightstreamer MQTT Extender.
Copy the `MQTT_Auth_demo.jar` from `lib` folder into `mqtt_connectors/lib` folder of your MQTT Extender installation and follow the project's README to configure the MQTT  Extender appropriately.
